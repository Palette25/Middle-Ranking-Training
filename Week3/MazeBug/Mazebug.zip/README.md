---
Author: Palette25
Description: README.md
---

# README for MazeBug

### File Structure
```
├── build
├── dist
├── framework
├── javadoc
├── lib
├── projects
├── build.properties
├── build.xml
├── MazeBug.java
├── README.md
```

### Use method
	1. I have finished the build.xml in this update package, so you just need to 
	   input ' ant ' in terminal and run this MazeBug.
	2. As for the mazes we need to call for testing, you can find them in lib file.